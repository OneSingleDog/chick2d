<?xml version="1.0" encoding="UTF-8"?>
<tileset name="river_all" tilewidth="32" tileheight="32" tilecount="615" columns="15">
 <image source="river_new.png" width="507" height="1327"/>
</tileset>
