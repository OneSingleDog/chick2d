<?xml version="1.0" encoding="UTF-8"?>
<tileset name="house1" tilewidth="32" tileheight="32" tilecount="216" columns="18">
 <image source="house1.png" width="580" height="386"/>
 <tile id="182">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
</tileset>
