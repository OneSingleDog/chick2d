<?xml version="1.0" encoding="UTF-8"?>
<tileset name="house1" tilewidth="32" tileheight="32" tilecount="3752" columns="8">
 <image source="室外.png" width="256" height="15008"/>
 <tile id="19">
  <properties>
   <property name="collidable" value="true"/>
  </properties>
 </tile>
</tileset>
