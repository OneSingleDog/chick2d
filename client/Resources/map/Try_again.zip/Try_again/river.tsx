<?xml version="1.0" encoding="UTF-8"?>
<tileset name="river" tilewidth="32" tileheight="32" tilecount="1036" columns="37">
 <image source="Tiny Green-河(River)_爱给网_aigei_com.png" width="1200" height="900"/>
</tileset>
