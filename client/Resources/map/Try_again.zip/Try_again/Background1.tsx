<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Background1" tilewidth="32" tileheight="32" tilecount="3808" columns="68">
 <image source="Tiny Green-大片的森林(Large Woods)_爱给网_aigei_com.png" width="2200" height="1800"/>
</tileset>
